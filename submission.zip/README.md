# COMP534_CA3
Applied AI Assignment 3
Alexander Pasha, Edward Long
Image Classification, A model to identify Covid and Pneumonia from X-ray chest scans

To run our notebook, open the .ipynb file preferably in google colab. 
To load the data in colab, either add it manually to colab's content folder, or place a kaggle.json api key in the content folder
and run the first few cells to quickly download the data from kaggle.com .
Otherwise, just place the data folder into the project folder.

Thereafter, everything should run within the ipynb environment.